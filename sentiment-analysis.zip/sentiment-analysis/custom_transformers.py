import re
import pandas as pd
import nltk
import gdown
from sklearn.base import BaseEstimator, TransformerMixin
from Sastrawi.StopWordRemover.StopWordRemoverFactory import StopWordRemoverFactory
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory


# 1. Case Folding
class CaseFoldingTransformer(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        # Pastikan setiap elemen adalah string
        X = [str(text) if not isinstance(text, str) else text for text in X]
        return [text.lower() for text in X]

# 2. Data Cleaning
class DataCleaningTransformer(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return [self.clean_text(text) for text in X]

    def clean_text(self, text):
        text = self.remove_emojis(text)
        text = self.remove_punctuation(text)
        text = self.remove_brackets_and_numbers(text)
        text = self.remove_double_quotes(text)
        text = self.remove_special_characters(text)
        return text

    def remove_emojis(self, text):
        emoji_pattern = re.compile(
            u"["
            u"\U0001F600-\U0001F64F"
            u"\U0001F300-\U0001F5FF"
            u"\U0001F680-\U0001F6FF"
            u"\U0001F1E0-\U0001F1FF"
            u"\U00002600-\U000026FF"
            u"\U00002300-\U000023FF"
            u"\U0001F900-\U0001F9FF"
            u"\U0001FA70-\U0001FAFF"
            u"\U00002700-\U000027BF"
            u"\U000024C2-\U0001F251"
            u"\U0001F000-\U0001F02F"
            u"\U0001F0A0-\U0001F0FF"
            u"\U0001F300-\U0001F5FA"
            u"\U0001F680-\U0001F6C5"
            u"\U0001F700-\U0001F773"
            u"\u2764"
            u"\u2708-\u270F"
            u"\U0001F48C-\U0001F48F"
            u"\U0001F926-\U0001F937"
            u"\U00010000-\U0010FFFF"
            u"\u2640-\u2642"
            u"\u2600-\u2B55"
            u"\u200d"
            u"\u23cf"
            u"\u23e9"
            u"\u231a"
            u"\ufe0f"
            u"\u3030"
            "]", flags=re.UNICODE)
        return emoji_pattern.sub(r'', text)

    def remove_punctuation(self, text):
        return re.sub(r'[.,;!?]', '', text)

    def remove_brackets_and_numbers(self, text):
        return re.sub(r'[\(\)\[\]\{\}0-9]', '', text)

    def remove_double_quotes(self, text):
        return text.replace('"', '')

    def remove_special_characters(self, text):
        return re.sub(r"[-'²*#:+/“”–_…½~¡¡¡⁰⁰`><…‘’&]", '', text)

# 3. Normalization
class NormalizationTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, file_id='1r-uJx9ZosLLj5EL4gspr53yUai-jpKJ0'):
        download_url = f'https://drive.google.com/uc?id={file_id}'
        output = 'Kamus Normalisasi.csv'
        gdown.download(download_url, output, quiet=False)
        self.normalizad_word = pd.read_csv(output)
        self.normalizad_word_dict = {row[0]: row[1] for _, row in self.normalizad_word.iterrows()}

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return [self.normalized_term(text) for text in X]

    def normalized_term(self, text):
        words = text.split()
        normalized_words = [self.normalizad_word_dict.get(word, word) for word in words]
        return " ".join(normalized_words)

# 4. Stopword Removal
class StopwordRemovalTransformer(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return [self.remove_stopwords(text) for text in X]

    def remove_stopwords(self, text):
        stopword_factory = StopWordRemoverFactory()
        sastrawi_stopwords = set(stopword_factory.get_stop_words())
        nltk_stopwords = set(nltk.corpus.stopwords.words('indonesian'))
        custom_stopwords = {'midi', 'kriing', 'midi kriing', 'untuk', 'pakai', 'belanja', 'harga', 'produk', 'barang', 'beli', 'dapat', 'buat', 'tapi', 'jadi'}
        all_stopwords = sastrawi_stopwords | nltk_stopwords | custom_stopwords
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        words = text.split()
        filtered_words = [word for word in words if word.lower() not in all_stopwords]
        return " ".join(filtered_words)

# 5. Stemming
class StemmingTransformer(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return [self.stem_words(text) for text in X]

    def stem_words(self, text):
        stemmer = StemmerFactory().create_stemmer()
        words = text.split()
        stemmed_words = [stemmer.stem(word) for word in words]
        return " ".join(stemmed_words)