from flask import Flask, render_template, request, redirect, url_for, send_file
from custom_transformers import CaseFoldingTransformer, DataCleaningTransformer, NormalizationTransformer, StopwordRemovalTransformer, StemmingTransformer
import pandas as pd
import joblib
import pickle
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Load preprocessing pipeline
pipeline = joblib.load('preprocessing_pipeline.pkl')

# Load TF-IDF vectorizers
import joblib
tfidf_produk = joblib.load('tfidf_aspek_produk.pkl')
tfidf_layanan = joblib.load('tfidf_aspek_layanan.pkl')
tfidf_fungsi = joblib.load('tfidf_aspek_fungsional.pkl')

# Load models
model_produk = joblib.load('model_aspek_produk.pkl')
model_layanan = joblib.load('model_aspek_layanan.pkl')
model_fungsi = joblib.load('model_aspek_fungsional.pkl')

hasil_analisis = []  # Global variable to store analysis result for export

@app.route('/analisisKalimat', methods=['GET', 'POST'])
def analisis_kalimat():
    if request.method == 'POST':
        input_text = request.form['input_text']
        preprocessed = pipeline.transform([input_text])

        # Transform with TF-IDF
        vec_produk = tfidf_produk.transform(preprocessed)
        vec_layanan = tfidf_layanan.transform(preprocessed)
        vec_fungsi = tfidf_fungsi.transform(preprocessed)

        pred_produk = model_produk.predict(vec_produk)[0]
        pred_layanan = model_layanan.predict(vec_layanan)[0]
        pred_fungsi = model_fungsi.predict(vec_fungsi)[0]

        return render_template('analisisKalimat.html', input_text=input_text,
                               pred_produk=pred_produk,
                               pred_layanan=pred_layanan,
                               pred_fungsi=pred_fungsi)

    return render_template('analisisKalimat.html')

@app.route('/analisisFile', methods=['GET', 'POST'])
def analisis_file():
    global hasil_analisis
    hasil_analisis = []
    data = None

    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)

        filename = secure_filename(file.filename)
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)

        df = pd.read_csv(filepath)
        if 'ulasan' not in df.columns:
            return "File CSV harus memiliki kolom 'ulasan'"
        if 'rating' not in df.columns:
            return "File CSV harus memiliki kolom 'rating'"

        preprocessed = pipeline.transform(df['ulasan'])

        produk_preds = model_produk.predict(tfidf_produk.transform(preprocessed))
        layanan_preds = model_layanan.predict(tfidf_layanan.transform(preprocessed))
        fungsi_preds = model_fungsi.predict(tfidf_fungsi.transform(preprocessed))

        df['produk'] = produk_preds
        df['layanan'] = layanan_preds
        df['fungsi'] = fungsi_preds

        # Store the results for export/download
        hasil_analisis = df[['ulasan', 'produk', 'layanan', 'fungsi', 'rating']].to_dict(orient='records')

        # Creating a dictionary to hold reviews categorized by aspect and sentiment
        reviews_by_aspect_and_sentiment = {
            'Produk': {'Positif': [], 'Negatif': [], 'Tidak Ada': []},
            'Layanan': {'Positif': [], 'Negatif': [], 'Tidak Ada': []},
            'Fungsional': {'Positif': [], 'Negatif': [], 'Tidak Ada': []}
        }

        # Populate the reviews dictionary based on the predicted sentiment
        for row in df.itertuples():
            reviews_by_aspect_and_sentiment['Produk'][row.produk].append(row.ulasan)
            reviews_by_aspect_and_sentiment['Layanan'][row.layanan].append(row.ulasan)
            reviews_by_aspect_and_sentiment['Fungsional'][row.fungsi].append(row.ulasan)

        return render_template('analisisFile.html', hasil=hasil_analisis, reviews=reviews_by_aspect_and_sentiment)

    return render_template('analisisFile.html', hasil=None)

@app.route('/')
def beranda():
    return render_template('beranda.html')


@app.route('/download_csv')
def download_csv():
    global hasil_analisis
    if not hasil_analisis:
        return redirect(url_for('analisis_file'))

    df = pd.DataFrame(hasil_analisis)
    output_path = os.path.join('static', 'hasil_analisis.csv')
    df.to_csv(output_path, index=False)
    return send_file(output_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
